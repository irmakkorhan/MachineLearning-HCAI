import pandas as pd
import os
import joblib

from sklearn.feature_extraction.text import TfidfVectorizer


INPUT_FILE = "data/processed/participant_texts.csv"
OUTPUT_FILE = "data/processed/set2_tfidf_features.csv"
VECTORIZER_FILE = "data/processed/tfidf_vectorizer.joblib"


def main():
    # 1. Load one-text-per-participant file
    df = pd.read_csv(INPUT_FILE)

    print("Loaded participant texts:")
    print(df.head())
    print("Shape:", df.shape)

    # 2. Make sure participant_id and full_text are clean
    df["participant_id"] = df["participant_id"].astype(str)
    df["full_text"] = df["full_text"].fillna("").astype(str)

    # 3. Create TF-IDF vectorizer
    tfidf = TfidfVectorizer(
        lowercase=True,
        ngram_range=(1, 2),      # use single words + two-word phrases
        min_df=2,                # keep terms appearing in at least 2 participants
        max_df=0.9,              # remove terms appearing in more than 90% of participants
        max_features=5000,       # keep at most 5000 TF-IDF features
        sublinear_tf=True        # reduce the effect of repeated words
    )

    # 4. Fit TF-IDF on participant full texts
    X_tfidf = tfidf.fit_transform(df["full_text"])

    # 5. Get feature names
    feature_names = tfidf.get_feature_names_out()

    # 6. Convert TF-IDF matrix to DataFrame
    tfidf_df = pd.DataFrame(
        X_tfidf.toarray(),
        columns=[f"tfidf_{feature}" for feature in feature_names]
    )

    # 7. Add participant_id back
    tfidf_df.insert(0, "participant_id", df["participant_id"].values)

    # 8. Save TF-IDF features
    tfidf_df.to_csv(OUTPUT_FILE, index=False)

    # 9. Save vectorizer for later use
    joblib.dump(tfidf, VECTORIZER_FILE)

    print("\nSet 2 TF-IDF features created successfully.")
    print(f"Saved to: {OUTPUT_FILE}")
    print(f"Vectorizer saved to: {VECTORIZER_FILE}")
    print("TF-IDF shape:", tfidf_df.shape)

    print("\nFirst 20 TF-IDF features:")
    print(feature_names[:20])


if __name__ == "__main__":
    main()
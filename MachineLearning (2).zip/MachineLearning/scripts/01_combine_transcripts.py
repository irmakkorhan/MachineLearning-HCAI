import pandas as pd
import glob
import os
import re

RAW_DATA_DIR = "data/raw/ALL_TRANSCRIPTS"
PROCESSED_DATA_DIR = "data/processed"
OUTPUT_FILE = os.path.join(PROCESSED_DATA_DIR, "all_transcripts_raw.csv")


def extract_participant_id(file_path):
    filename = os.path.basename(file_path)
    match = re.search(r"(\d+)_TRANSCRIPT", filename)

    if match is None:
        raise ValueError(f"Could not extract participant ID from: {filename}")

    return match.group(1)


def main():
    os.makedirs(PROCESSED_DATA_DIR, exist_ok=True)

    transcript_files = glob.glob(os.path.join(RAW_DATA_DIR, "*_TRANSCRIPT.csv"))

    if len(transcript_files) == 0:
        raise FileNotFoundError("No transcript files found in data/raw")

    all_dfs = []

    for file_path in transcript_files:
        participant_id = extract_participant_id(file_path)

        df = pd.read_csv(file_path, sep="\t")
        df["participant_id"] = participant_id

        all_dfs.append(df)

    combined_df = pd.concat(all_dfs, ignore_index=True)

    combined_df.to_csv(OUTPUT_FILE, index=False)

    print("Done. Combined transcript file created.")
    print(f"Saved to: {OUTPUT_FILE}")
    print(combined_df.head())
    print(combined_df.shape)


if __name__ == "__main__":
    main()
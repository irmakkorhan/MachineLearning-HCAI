import pandas as pd
import numpy as np
import re


INPUT_FILE = "data/processed/participant_rows_clean.csv"
OUTPUT_FILE = "data/processed/set1_linguistic_features.csv"


fillers = {
    "um", "uh", "umm", "hmm", "mhm", "erm"
}

negations = {
    "no", "not", "never", "nothing", "nobody",
    "cannot", "can't", "dont", "don't",
    "didn't", "isn't", "wasn't", "won't"
}

first_person = {
    "i", "me", "my", "mine", "myself"
}

hedges = {
    "maybe", "probably", "perhaps", "guess",
    "kinda", "kind", "sort", "think",
    "unsure"
}


def tokenize(text):
    """
    Simple tokenizer.
    Keeps contractions like don't as one token.
    """
    return re.findall(r"\b[\w']+\b", str(text).lower())


def extract_features_for_participant(group):
    texts = group["value_clean"].fillna("").astype(str).tolist()
    full_text = " ".join(texts)

    tokens = tokenize(full_text)
    total_words = len(tokens)

    # Avoid division by zero
    if total_words == 0:
        total_words_safe = 1
    else:
        total_words_safe = total_words

    words_per_turn = [len(tokenize(text)) for text in texts]

    filler_count = sum(token in fillers for token in tokens)
    negation_count = sum(token in negations for token in tokens)
    first_person_count = sum(token in first_person for token in tokens)
    hedge_count = sum(token in hedges for token in tokens)

    features = {
        "word_count": total_words,
        "turn_count": len(texts),

        "avg_words_per_turn": np.mean(words_per_turn) if words_per_turn else 0,
        "short_answer_rate": np.mean([w <= 3 for w in words_per_turn]) if words_per_turn else 0,

        "filler_count": filler_count,
        "filler_rate": filler_count / total_words_safe,

        "negation_count": negation_count,
        "negation_rate": negation_count / total_words_safe,

        "first_person_count": first_person_count,
        "first_person_rate": first_person_count / total_words_safe,

        "hedge_count": hedge_count,
        "hedge_rate": hedge_count / total_words_safe,

        "no_answer_count": full_text.count("no answer"),
        "laughter_count": full_text.count("laughter"),

        "avg_duration": group["duration"].mean(),
        "total_speaking_time": group["duration"].sum(),
        "max_duration": group["duration"].max(),
    }

    return pd.Series(features)


def main():
    df = pd.read_csv(INPUT_FILE)

    df["participant_id"] = df["participant_id"].astype(str)

    set1_features = (
        df
        .groupby("participant_id")
        .apply(extract_features_for_participant)
        .reset_index()
    )

    set1_features.to_csv(OUTPUT_FILE, index=False)

    print("Set 1 linguistic features created.")
    print(f"Saved to: {OUTPUT_FILE}")
    print(set1_features.head())
    print("Shape:", set1_features.shape)


if __name__ == "__main__":
    main()
import pandas as pd


SET1_FILE = "data/processed/set1_linguistic_features.csv"
SET2_FILE = "data/processed/set2_tfidf_features.csv"

OUTPUT_FILE = "data/processed/set3_combined_features.csv"


def main():
    # 1. Load Set 1 and Set 2
    set1 = pd.read_csv(SET1_FILE)
    set2 = pd.read_csv(SET2_FILE)

    print("Set 1 shape:", set1.shape)
    print("Set 2 shape:", set2.shape)

    # 2. Make sure participant_id has the same type in both files
    set1["participant_id"] = set1["participant_id"].astype(str)
    set2["participant_id"] = set2["participant_id"].astype(str)

    # 3. Merge Set 1 and Set 2 using participant_id
    combined = pd.merge(
        set1,
        set2,
        on="participant_id",
        how="inner"
    )

    # 4. Save combined features
    combined.to_csv(OUTPUT_FILE, index=False)

    print("\nSet 3 combined features created successfully.")
    print(f"Saved to: {OUTPUT_FILE}")
    print("Combined shape:", combined.shape)
    print(combined.head())


if __name__ == "__main__":
    main()
import pandas as pd
import os
import re


INPUT_FILE = "data/processed/all_transcripts_raw.csv"

OUTPUT_PARTICIPANT_ROWS = "data/processed/participant_rows_clean.csv"
OUTPUT_PARTICIPANT_TEXTS = "data/processed/participant_texts.csv"


def clean_text(text):
    """
    Basic text cleaning.
    We keep useful speech markers like:
    um, uh, no, not, don't, laughter, no answer
    because they may be useful for depression prediction.
    """
    text = str(text).lower()
    text = text.strip()
    text = re.sub(r"\s+", " ", text)
    return text


def main():
    # 1. Load combined raw transcript file
    df = pd.read_csv(INPUT_FILE)

    print("Original raw file:")
    print(df.head())
    print("Shape:", df.shape)

    # 2. Make sure text is clean and participant_id is string
    df["participant_id"] = df["participant_id"].astype(str)
    df["value"] = df["value"].fillna("").astype(str)

    df["value_clean"] = df["value"].apply(clean_text)

    # 3. Keep only Participant rows
    participant_df = df[df["speaker"] == "Participant"].copy()

    # 4. Calculate duration of each participant answer
    participant_df["duration"] = (
        participant_df["stop_time"] - participant_df["start_time"]
    )

    # 5. Save clean participant rows
    participant_df.to_csv(OUTPUT_PARTICIPANT_ROWS, index=False)

    # 6. Create one full text per participant
    participant_texts = (
        participant_df
        .groupby("participant_id")["value_clean"]
        .apply(lambda rows: " ".join(rows))
        .reset_index()
    )

    participant_texts = participant_texts.rename(
        columns={"value_clean": "full_text"}
    )

    # 7. Save one-text-per-participant file
    participant_texts.to_csv(OUTPUT_PARTICIPANT_TEXTS, index=False)

    print("\nParticipant-only rows created:")
    print(participant_df.head())
    print("Shape:", participant_df.shape)

    print("\nOne full text per participant created:")
    print(participant_texts.head())
    print("Shape:", participant_texts.shape)

    print("\nSaved files:")
    print(OUTPUT_PARTICIPANT_ROWS)
    print(OUTPUT_PARTICIPANT_TEXTS)


if __name__ == "__main__":
    main()